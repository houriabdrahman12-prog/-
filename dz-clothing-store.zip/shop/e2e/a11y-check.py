"""Accessibility smoke check (Playwright): every visible form control has an accessible name, images have alt, one <h1>/landmarks exist.
Usage: BASE=http://localhost:3113 ADMIN_EMAIL=.. ADMIN_PASSWORD=.. python3 e2e/a11y-check.py"""
import os, sys
from playwright.sync_api import sync_playwright
BASE = os.environ.get('BASE', 'http://localhost:3111'); EMAIL, PW = os.environ['ADMIN_EMAIL'], os.environ['ADMIN_PASSWORD']
JS = """() => [...document.querySelectorAll('input,select,textarea')].filter(e => e.type !== 'hidden' && e.offsetParent !== null && !e.classList.contains('hp')).filter(e => {
  const lab = e.labels && e.labels.length; const name = (e.getAttribute('aria-label') || '').trim() || (e.getAttribute('aria-labelledby')) || lab;
  return !name; }).map(e => (e.id || e.className || e.tagName) + ':' + (e.placeholder || e.type))"""
IMG = "() => [...document.querySelectorAll('img')].filter(i => !i.hasAttribute('alt')).length"
bad = []
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={'width': 1200, 'height': 800})
    pg.goto(BASE + '/'); pg.wait_for_selector('#home-dyn .card'); pg.wait_for_selector('#intro', state='detached')
    for label, js in (('store home', JS),): bad += [f'{label}: unnamed control {x}' for x in pg.evaluate(js)]
    bad += [f'store: {pg.evaluate(IMG)} <img> without alt'] if pg.evaluate(IMG) else []
    assert pg.locator('a.skip').count() == 1 and pg.locator('main').count() == 1 and pg.locator('h1').count() >= 1
    pg.click('[data-act=cart]'); pg.wait_for_timeout(300)
    a = b.new_page(viewport={'width': 1300, 'height': 800}); a.goto(BASE + '/admin'); a.wait_for_selector('#lf'); bad += [f'login: unnamed control {x}' for x in a.evaluate(JS)]
    a.fill('#em', EMAIL); a.fill('#pw', PW); a.click('#lf button'); a.wait_for_selector('.cards .card')
    for hashp, h1 in [('orders', 'Orders'), ('products', 'Products'), ('products/new', 'New product'), ('inventory', 'Inventory'), ('categories', 'Categories'), ('coupons', 'Coupons'), ('delivery', 'Wilayas'), ('settings', 'Settings'), ('users', 'Admin users'), ('reviews', 'Reviews')]:
        a.goto(BASE + '/admin#/' + hashp); a.wait_for_selector(f'h1:has-text("{h1}")'); a.wait_for_timeout(250)
        bad += [f'admin/{hashp}: unnamed control {x}' for x in a.evaluate(JS)]
    b.close()
if bad: print('\n'.join(bad[:40])); sys.exit(1)
print('A11Y OK')
