"""iPhone-size layout check (Chromium emulation at 375/390/430px): no horizontal overflow, inputs >= 16px (no iOS zoom-on-focus),
viewport meta, safe-area. Usage: BASE=http://localhost:3111 ADMIN_EMAIL=.. ADMIN_PASSWORD=.. python3 e2e/mobile-check.py
Needs a dev server seeded with `npm run seed:demo`."""
import os, sys
from playwright.sync_api import sync_playwright
BASE = os.environ.get('BASE', 'http://localhost:3111'); EMAIL, PW = os.environ['ADMIN_EMAIL'], os.environ['ADMIN_PASSWORD']
SHOTS = os.environ.get('SHOTS', '/tmp/shots'); os.makedirs(SHOTS, exist_ok=True)
OVER = """() => { const W = window.innerWidth; const bad = [];
  for (const e of document.querySelectorAll('body *')) { const r = e.getBoundingClientRect(); if (r.width === 0 || r.height === 0 || getComputedStyle(e).position === 'fixed') continue;
    if (r.right > W + 1 || r.left < -1) { let p = e.parentElement, scroller = false; while (p) { const o = getComputedStyle(p).overflowX; if (/(auto|scroll|hidden)/.test(o) && p !== document.body && p !== document.documentElement) { scroller = true; break; } p = p.parentElement; } if (!scroller) bad.push((e.id || e.className || e.tagName) + ' ' + Math.round(r.left) + '..' + Math.round(r.right)); } }
  return { scrollW: document.documentElement.scrollWidth, W, bad: bad.slice(0, 6) }; }"""
SMALLINPUT = "() => [...document.querySelectorAll('input,select,textarea')].filter(e => e.offsetParent !== null && e.type !== 'hidden' && e.type !== 'checkbox' && !e.classList.contains('hp') && parseFloat(getComputedStyle(e).fontSize) < 16).map(e => e.id || e.className).slice(0, 5)"
problems = []
def check(pg, label):
    r = pg.evaluate(OVER); s = pg.evaluate(SMALLINPUT)
    if r['scrollW'] > r['W'] + 1 or r['bad']: problems.append(f"{label}: overflow scrollW={r['scrollW']} W={r['W']} {r['bad']}")
    if s: problems.append(f"{label}: inputs <16px (iOS zoom) {s}")
with sync_playwright() as p:
    b = p.chromium.launch()
    for w, h, name in ((375, 667, 'iphone-se'), (390, 844, 'iphone-13'), (430, 932, 'iphone-pro-max')):
        ctx = b.new_context(viewport={'width': w, 'height': h}, device_scale_factor=2, is_mobile=True, has_touch=True); pg = ctx.new_page()
        pg.goto(BASE + '/'); pg.wait_for_selector('#intro', state='detached', timeout=9000); pg.wait_for_selector('#home-dyn .card'); assert 'viewport-fit=cover' in pg.content()
        check(pg, f'{name} home'); pg.screenshot(path=f'{SHOTS}/m-{name}-home.png')
        pg.goto(BASE + '/shop'); pg.wait_for_selector('#grid .card'); pg.click('[data-act=filters]'); check(pg, f'{name} shop+filters')
        pg.locator('#grid .cardlink').first.click(); pg.wait_for_selector('#pd.on .opt'); pg.wait_for_timeout(600); check(pg, f'{name} product'); pg.screenshot(path=f'{SHOTS}/m-{name}-product.png')
        pg.locator('#pd .opt[data-act=size]:not([disabled])').first.click(); pg.locator('#pd [data-act=add]').click(); pg.click('#pd [data-act=close]')
        pg.click('[data-act=cart]'); pg.wait_for_selector('#c-name'); pg.wait_for_timeout(600); check(pg, f'{name} checkout'); pg.screenshot(path=f'{SHOTS}/m-{name}-checkout.png')
        pg.click('#cart [data-act=close]'); pg.click('[data-act=account]'); pg.wait_for_selector('#a-phone'); pg.wait_for_timeout(500); check(pg, f'{name} account'); pg.click('#acc [data-act=close]')
        pg.goto(BASE + '/page/contact'); pg.wait_for_selector('#v-page:not([hidden]) .txt'); check(pg, f'{name} legal'); pg.goto(BASE + '/nope-404'); check(pg, f'{name} 404')
        a = b.new_context(viewport={'width': w, 'height': h}, device_scale_factor=2, is_mobile=True, has_touch=True).new_page()
        a.goto(BASE + '/admin'); a.wait_for_selector('#lf'); check(a, f'{name} admin login'); a.fill('#em', EMAIL); a.fill('#pw', PW); a.click('#lf button'); a.wait_for_selector('.cards .card'); a.wait_for_timeout(500); check(a, f'{name} admin dashboard'); a.screenshot(path=f'{SHOTS}/m-{name}-admin.png')
        for hp, h1 in (('orders', 'Orders'), ('products', 'Products'), ('products/new', 'New product'), ('inventory', 'Inventory'), ('delivery', 'Wilayas'), ('settings', 'Settings'), ('coupons', 'Coupons')):
            a.goto(BASE + '/admin#/' + hp); a.wait_for_selector(f'h1:has-text("{h1}")'); a.wait_for_timeout(250); check(a, f'{name} admin/{hp}')
        ctx.close()
    b.close()
if problems: print('\n'.join(problems[:30])); sys.exit(1)
print('MOBILE OK (375/390/430px)')
