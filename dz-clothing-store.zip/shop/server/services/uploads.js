'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { createRequire } = require('node:module');
const { HttpError } = require('../errors');

function sniff(buf) {
  if (buf.length < 12) return null;
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'jpg';
  if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'png';
  if (buf.subarray(0, 4).toString('latin1') === 'RIFF' && buf.subarray(8, 12).toString('latin1') === 'WEBP') return 'webp';
  if (buf.subarray(0, 4).toString('latin1') === 'GIF8') return 'gif';
  return null;
}
const TYPES = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif' };

/** Validates by size, declared type AND magic bytes (never trusts the filename). Optionally optimizes with `sharp` if installed. */
async function saveImage(config, buf, declaredType) {
  if (!buf || !buf.length) throw new HttpError(400, 'EMPTY', 'Empty upload');
  if (buf.length > config.maxUploadBytes) throw new HttpError(413, 'TOO_LARGE', `Image too large (max ${Math.round(config.maxUploadBytes / 1048576)}MB)`);
  const ext = sniff(buf);
  const declared = TYPES[String(declaredType || '').split(';')[0].trim().toLowerCase()];
  if (!ext || ext !== declared) throw new HttpError(415, 'BAD_IMAGE', 'Only JPEG, PNG, WebP or GIF images are allowed');
  let out = buf, outExt = ext, thumb = null;
  try {
    const sharp = createRequire(path.join(config.root, 'package.json'))('sharp');
    if (ext !== 'gif') {
      out = await sharp(buf).rotate().resize({ width: 1600, withoutEnlargement: true }).webp({ quality: 82 }).toBuffer(); outExt = 'webp';
      thumb = await sharp(buf).rotate().resize({ width: 480, withoutEnlargement: true }).webp({ quality: 75 }).toBuffer();
    }
  } catch { /* sharp not installed (or image undecodable): store the validated original */ }
  fs.mkdirSync(config.uploadDir, { recursive: true });
  const id = crypto.randomUUID();
  fs.writeFileSync(path.join(config.uploadDir, `${id}.${outExt}`), out, { mode: 0o644 });
  if (thumb) fs.writeFileSync(path.join(config.uploadDir, `${id}-t.webp`), thumb, { mode: 0o644 });
  return `/uploads/${id}.${outExt}`;
}
module.exports = { saveImage, sniff };
