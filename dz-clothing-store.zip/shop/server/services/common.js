'use strict';
const crypto = require('node:crypto');

function getSettings(db) {
  const o = {};
  for (const r of db.prepare('SELECT key,value FROM settings').all()) o[r.key] = r.value;
  return o;
}
function audit(db, { actor, action, entity, entityId, detail, ip }) {
  db.prepare('INSERT INTO audit_logs(actor_kind,actor_id,actor_email,action,entity,entity_id,detail,ip) VALUES(?,?,?,?,?,?,?,?)')
    .run(actor?.kind || 'system', actor?.id ?? null, actor?.email ?? null, action, entity ?? null, entityId != null ? String(entityId) : null,
      detail ? JSON.stringify(detail).slice(0, 4000) : null, ip ?? null);
}
/** customerId = null -> admin notification center; customerId set -> that customer's own notifications. */
function notify(db, { type, title, body, link, customerId = null }) {
  db.prepare('INSERT INTO notifications(type,title,body,link,customer_id) VALUES(?,?,?,?,?)').run(type, title, body ?? null, link ?? null, customerId);
}
const adminActor = (a) => ({ kind: 'admin', id: a.id, email: a.email });

const signPayload = (secret, body) => crypto.createHmac('sha256', secret).update(body).digest('hex');
/** Fire-and-forget signed webhook (HMAC-SHA256 hex of the raw body in X-Signature) for external integrations (WhatsApp/SMS/email gateways, Zapier, n8n...). */
function fireWebhook(app, event, payload) {
  try {
    const url = getSettings(app.db).notify_webhook_url;
    if (!url || !/^https:\/\//i.test(url)) return;
    const body = JSON.stringify({ event, at: new Date().toISOString(), data: payload });
    const headers = { 'Content-Type': 'application/json' };
    if (app.config.webhookSecret) headers['X-Signature'] = signPayload(app.config.webhookSecret, body);
    (app.fetch || fetch)(url, { method: 'POST', headers, body, signal: AbortSignal.timeout(5000), redirect: 'error' })
      .catch((e) => app.log.warn('webhook_failed', { err: e.message }));
  } catch (e) { app.log.warn('webhook_error', { err: e.message }); }
}
/** Store time zone as a whole-hour UTC offset (Algeria = +1). Used for day grouping in reports. */
const tzHours = (db) => { const v = Number(db.prepare("SELECT value FROM settings WHERE key='tz_offset_hours'").get()?.value); return Number.isInteger(v) && v >= -12 && v <= 14 ? v : 1; };
const tzSql = (db) => { const h = tzHours(db); return `'${h >= 0 ? '+' : '-'}${Math.abs(h)} hour'`; };
const toInt = (v) => (typeof v === 'bigint' ? Number(v) : v);
const lastId = (r) => Number(r.lastInsertRowid);
module.exports = { tzHours, tzSql, signPayload, getSettings, audit, notify, adminActor, fireWebhook, toInt, lastId };
