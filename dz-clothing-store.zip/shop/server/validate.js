'use strict';
const { HttpError } = require('./errors');

/** Tiny validation toolkit: collect field errors then throw one 422. */
class V {
  constructor(src) { this.src = src && typeof src === 'object' && !Array.isArray(src) ? src : {}; this.errors = {}; this.out = {}; }
  fail(f, m) { this.errors[f] = m; return undefined; }
  str(f, { min = 0, max = 500, required = true, re, msg, trim = true } = {}) {
    let v = this.src[f];
    if (v == null || v === '') { if (required) return this.fail(f, 'required'); return (this.out[f] = null); }
    if (typeof v !== 'string') return this.fail(f, 'must be text');
    if (trim) v = v.trim();
    v = v.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '');
    if (v.length < min) return this.fail(f, `min ${min} characters`);
    if (v.length > max) return this.fail(f, `max ${max} characters`);
    if (re && !re.test(v)) return this.fail(f, msg || 'invalid format');
    return (this.out[f] = v);
  }
  int(f, { min = -Infinity, max = Infinity, required = true } = {}) {
    const v = this.src[f];
    if (v == null || v === '') { if (required) return this.fail(f, 'required'); return (this.out[f] = null); }
    const n = typeof v === 'string' && /^-?\d+$/.test(v) ? Number(v) : v;
    if (!Number.isSafeInteger(n)) return this.fail(f, 'must be an integer');
    if (n < min || n > max) return this.fail(f, `must be between ${min} and ${max}`);
    return (this.out[f] = n);
  }
  bool(f, def = false) {
    const v = this.src[f];
    if (v == null) return (this.out[f] = def ? 1 : 0);
    return (this.out[f] = v === true || v === 1 || v === '1' || v === 'true' ? 1 : 0);
  }
  oneOf(f, list, { required = true } = {}) {
    const v = this.src[f];
    if (v == null || v === '') { if (required) return this.fail(f, 'required'); return (this.out[f] = null); }
    if (!list.includes(v)) return this.fail(f, 'invalid value');
    return (this.out[f] = v);
  }
  done() { if (Object.keys(this.errors).length) throw new HttpError(422, 'VALIDATION', 'Invalid data', this.errors); return this.out; }
}

const PHONE_RE = /^0[5-7]\d{8}$/; // Algerian mobile numbers: 05XXXXXXXX / 06XXXXXXXX / 07XXXXXXXX
function normalizePhone(p) {
  if (typeof p !== 'string') return null;
  let s = p.replace(/[\s.\-()]/g, '');
  if (s.startsWith('+213')) s = '0' + s.slice(4);
  else if (s.startsWith('00213')) s = '0' + s.slice(5);
  else if (s.startsWith('213') && s.length === 12) s = '0' + s.slice(3);
  return PHONE_RE.test(s) ? s : null;
}
const EMAIL_RE = /^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,}$/;
const ID_RE = /^[1-9]\d{0,9}$/;
function slugify(s) {
  const base = String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 80);
  return base;
}
const toIntl = (p) => (typeof p === 'string' && PHONE_RE.test(p) ? '213' + p.slice(1) : null); // 0555123456 -> 213555123456
const likeEscape = (s) => s.replace(/[\\%_]/g, (m) => '\\' + m);

module.exports = { V, toIntl, normalizePhone, PHONE_RE, EMAIL_RE, ID_RE, slugify, likeEscape };
