'use strict';
const crypto = require('node:crypto');
const { promisify } = require('node:util');
const scrypt = promisify(crypto.scrypt);

const N = 32768, R = 8, P = 1, KEYLEN = 64;
const MAXMEM = 128 * 1024 * 1024;

async function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const hash = await scrypt(pw, salt, KEYLEN, { N, r: R, p: P, maxmem: MAXMEM });
  return `scrypt$${N}$${R}$${P}$${salt.toString('base64')}$${hash.toString('base64')}`;
}
let DUMMY = null;
async function verifyPassword(pw, stored) {
  if (!stored) { DUMMY ||= await hashPassword('dummy-password-for-timing'); stored = DUMMY; pw = pw + '\0'; }
  const [alg, n, r, p, salt, hash] = stored.split('$');
  if (alg !== 'scrypt') return false;
  const expected = Buffer.from(hash, 'base64');
  const got = await scrypt(pw, Buffer.from(salt, 'base64'), expected.length, { N: +n, r: +r, p: +p, maxmem: MAXMEM });
  return crypto.timingSafeEqual(got, expected) && stored !== DUMMY;
}
function passwordProblem(pw) {
  if (typeof pw !== 'string' || pw.length < 12) return 'Password must be at least 12 characters.';
  if (pw.length > 200) return 'Password too long.';
  if (!/[a-zA-Z]/.test(pw) || !/[0-9]/.test(pw)) return 'Password must contain letters and digits.';
  return null;
}

const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
const sqlTime = (ms) => new Date(ms).toISOString().slice(0, 19).replace('T', ' ');
const rand = (n = 32) => crypto.randomBytes(n).toString('base64url');
const safeEq = (a, b) => {
  const x = Buffer.from(String(a)), y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};

function createSession(db, { kind, subjectId, ttlMs, ip, ua }) {
  const token = rand(32), csrf = rand(24);
  db.prepare('INSERT INTO sessions(token_hash,kind,subject_id,csrf,expires_at,ip,ua) VALUES(?,?,?,?,?,?,?)')
    .run(sha256(token), kind, subjectId, csrf, sqlTime(Date.now() + ttlMs), ip || null, (ua || '').slice(0, 200));
  return { token, csrf, expires: Date.now() + ttlMs };
}
function getSession(db, token, kind) {
  if (!token || typeof token !== 'string' || token.length > 100) return null;
  return db.prepare("SELECT * FROM sessions WHERE token_hash=? AND kind=? AND expires_at>datetime('now')").get(sha256(token), kind) || null;
}
function destroySession(db, token) { if (token) db.prepare('DELETE FROM sessions WHERE token_hash=?').run(sha256(token)); }
/** One-time password-reset token (stored hashed, 1h default, previous unused tokens invalidated). */
function createPasswordReset(db, customerId, { ttlMs = 3600_000, adminId = null } = {}) {
  const token = rand(32);
  db.prepare("UPDATE password_resets SET used_at=datetime('now') WHERE customer_id=? AND used_at IS NULL").run(customerId);
  db.prepare('INSERT INTO password_resets(customer_id,token_hash,expires_at,created_by_admin) VALUES(?,?,?,?)').run(customerId, sha256(token), sqlTime(Date.now() + ttlMs), adminId);
  return token;
}
function consumePasswordReset(db, token) {
  if (typeof token !== 'string' || token.length < 20 || token.length > 100) return null;
  const r = db.prepare("SELECT * FROM password_resets WHERE token_hash=? AND used_at IS NULL AND expires_at>datetime('now')").get(sha256(token));
  if (!r) return null;
  db.prepare("UPDATE password_resets SET used_at=datetime('now') WHERE id=?").run(r.id);
  return r.customer_id;
}
function purgeSessions(db) { db.prepare("DELETE FROM sessions WHERE expires_at<=datetime('now')").run(); }

function serializeCookie(name, value, o = {}) {
  let c = `${name}=${value}; Path=${o.path || '/'}; HttpOnly; SameSite=Strict`;
  if (o.secure) c += '; Secure';
  if (o.maxAge != null) c += `; Max-Age=${Math.floor(o.maxAge)}`;
  return c;
}
function parseCookies(h) {
  const out = {};
  if (!h) return out;
  for (const part of h.split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = part.slice(i + 1).trim();
  }
  return out;
}

/** Sliding-window in-memory limiter. For multi-instance deployments put a shared limiter (nginx/Cloudflare) in front. */
class RateLimiter {
  constructor() { this.hits = new Map(); this.t = setInterval(() => this.gc(), 60_000); this.t.unref?.(); }
  hit(key, max, windowMs) {
    const now = Date.now();
    const arr = (this.hits.get(key) || []).filter((t) => now - t < windowMs);
    if (arr.length >= max) { this.hits.set(key, arr); return { ok: false, retryAfter: Math.ceil((windowMs - (now - arr[0])) / 1000) }; }
    arr.push(now); this.hits.set(key, arr);
    return { ok: true };
  }
  gc() { const now = Date.now(); for (const [k, v] of this.hits) if (!v.length || now - v[v.length - 1] > 3_600_000) this.hits.delete(k); }
  reset() { this.hits.clear(); }
}

module.exports = { createPasswordReset, consumePasswordReset, hashPassword, verifyPassword, passwordProblem, sha256, sqlTime, rand, safeEq, createSession, getSession, destroySession, purgeSessions, serializeCookie, parseCookies, RateLimiter };
