#!/usr/bin/env bash
# One-command installer for a fresh Ubuntu 22.04/24.04 server (run as root):  bash install.sh
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "Run as root (sudo -i)"; exit 1; }
cd "$(dirname "$0")"
read -rp "Your domain (e.g. mystore.com, DNS A-record must already point to this server): " DOMAIN
DOMAIN="${DOMAIN#https://}"; DOMAIN="${DOMAIN%%/*}"
[[ "$DOMAIN" =~ ^[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]] || { echo "Invalid domain"; exit 1; }
read -rp "Admin email: " AEMAIL
read -rsp "Admin password (12+ chars, letters+digits): " APASS; echo

echo "== Installing Docker and Caddy"
command -v docker >/dev/null || curl -fsSL https://get.docker.com | sh
if ! command -v caddy >/dev/null; then
  apt-get update -y && apt-get install -y debian-keyring debian-archive-keyring apt-transport-https curl gpg
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor --yes -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' > /etc/apt/sources.list.d/caddy-stable.list
  apt-get update -y && apt-get install -y caddy
fi

echo "== Configuring"
[ -f .env ] || cp .env.example .env
sed -i "s#^BASE_URL=.*#BASE_URL=https://${DOMAIN}#" .env && chmod 600 .env
docker compose up -d --build
for i in $(seq 1 30); do curl -fs http://127.0.0.1:3000/health >/dev/null && break; sleep 2; done
curl -fs http://127.0.0.1:3000/health >/dev/null || { echo "App did not start: docker compose logs"; exit 1; }
docker compose exec -T -e ADMIN_EMAIL="$AEMAIL" -e ADMIN_PASSWORD="$APASS" shop node scripts/create-admin.js

printf '%s {\n  encode gzip\n  reverse_proxy 127.0.0.1:3000\n}\n' "$DOMAIN" > /etc/caddy/Caddyfile
systemctl reload caddy || systemctl restart caddy
ufw allow 80,443/tcp >/dev/null 2>&1 || true
echo; echo "DONE. Open https://${DOMAIN}/admin  (HTTPS certificate may take ~1 minute the first time)"
