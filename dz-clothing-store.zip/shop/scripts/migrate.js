'use strict';
// npm run migrate           -> create/upgrade the database (idempotent, non-destructive: only forward migrations)
// npm run migrate -- --check -> verify migrations apply on a throw-away in-memory database (used by `npm run build`)
const config = require('../server/config');
const dbm = require('../server/db');
const check = process.argv.includes('--check');
const db = dbm.open(check ? ':memory:' : config.dbPath);
dbm.migrate(db);
const v = db.prepare('PRAGMA user_version').get().user_version;
if (check) { const fk = db.prepare('PRAGMA foreign_key_check').all(); if (fk.length) { console.error('foreign key problems', fk); process.exit(1); } console.log(`migrations OK (schema v${v})`); }
else console.log(`Database ready at ${config.dbPath} (schema v${v})`);
