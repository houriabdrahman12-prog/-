'use strict';
// Usage: ADMIN_EMAIL=you@x.com ADMIN_PASSWORD='long-pass-123' npm run create-admin   (or run without env to be prompted)
const readline = require('node:readline');
const config = require('../server/config');
const dbm = require('../server/db');
const sec = require('../server/security');
const { EMAIL_RE } = require('../server/validate');

function ask(q, hidden) {
  return new Promise((res) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    if (hidden) { rl._writeToOutput = (s) => { if (s.includes(q)) process.stdout.write(s); else process.stdout.write('*'); }; }
    rl.question(q, (a) => { rl.close(); if (hidden) process.stdout.write('\n'); res(a); });
  });
}
(async () => {
  const db = dbm.open(config.dbPath); dbm.migrate(db);
  const email = (process.env.ADMIN_EMAIL || await ask('Admin email: ')).trim();
  const name = (process.env.ADMIN_NAME || 'Owner').trim();
  const pw = process.env.ADMIN_PASSWORD || await ask('Password (min 12 chars, letters+digits): ', true);
  if (!EMAIL_RE.test(email)) { console.error('Invalid email'); process.exit(1); }
  const problem = sec.passwordProblem(pw);
  if (problem) { console.error(problem); process.exit(1); }
  if (db.prepare('SELECT 1 FROM admin_users WHERE email=?').get(email)) { console.error('An admin with this email already exists.'); process.exit(1); }
  const role = db.prepare("SELECT id FROM roles WHERE code='super_admin'").get();
  db.prepare('INSERT INTO admin_users(email,name,password_hash,role_id) VALUES(?,?,?,?)').run(email, name, await sec.hashPassword(pw), role.id);
  console.log(`Super Admin created: ${email}\nLogin at /admin`);
})();
