'use strict';
const { test, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const { start, Client, adminClient, seedShop, orderBody } = require('./helpers');
const orders = require('../server/services/orders');

let ctx, adm, shop, pub;
const stockOf = (id) => ctx.db.prepare('SELECT stock FROM product_variants WHERE id=?').get(id).stock;
before(async () => { ctx = await start(); adm = await adminClient(ctx, 'super_admin'); shop = await seedShop(adm, { stock: 100, price: 3000, fee: 500 }); pub = new Client(ctx.base); });
after(async () => { await ctx.close(); });
beforeEach(() => ctx.app.limiter.reset());

test('Delivery calculation comes from the database (wilaya rate, commune override, inactive/unknown wilaya)', async () => {
  const q = (w, commune = '') => pub.post('/api/quote', { items: [{ variant_id: shop.variantM.id, qty: 2 }], wilaya_code: w, commune });
  let r = await q(16); assert.equal(r.status, 200); assert.equal(r.data.subtotal, 6000); assert.equal(r.data.delivery_fee, 500); assert.equal(r.data.total, 6500);
  assert.deepEqual([r.data.delivery.days_min, r.data.delivery.days_max], [1, 2]);
  // wilaya with no configured rate -> delivery unavailable (no invented prices)
  r = await q(31); assert.equal(r.status, 422); assert.equal(r.data.error.code, 'DELIVERY_UNAVAILABLE');
  // commune-specific price overrides the wilaya price
  await adm.post('/api/admin/delivery/rates', { wilaya_code: 16, commune: 'Hydra', price: 300, days_min: 1, days_max: 1, active: true });
  r = await q(16, 'hydra'); assert.equal(r.data.delivery_fee, 300);
  r = await q(16, 'Other'); assert.equal(r.data.delivery_fee, 500);
  // admin changes price -> customer sees the new one
  await adm.post('/api/admin/delivery/rates', { wilaya_code: 16, price: 650, days_min: 1, days_max: 3, active: true });
  assert.equal((await q(16)).data.delivery_fee, 650);
  // disabling the wilaya disables delivery
  await adm.post('/api/admin/delivery/rates', { wilaya_code: 16, price: 650, active: false });
  assert.equal((await q(16, 'Other')).status, 422);
  await adm.post('/api/admin/delivery/rates', { wilaya_code: 16, price: 500, days_min: 1, days_max: 2, active: true });
  // public config lists only wilayas that have an active rate
  const cfg = (await pub.get('/api/config')).data; assert.deepEqual(cfg.wilayas.map((w) => w.code), [16]); assert.equal(cfg.wilayas[0].price, 500);
  assert.equal((await adm.post('/api/admin/delivery/rates', { wilaya_code: 99, price: 1 })).status, 422);
  // bulk set for several wilayas
  await adm.post('/api/admin/delivery/rates', { wilaya_codes: [31, 25], price: 700, days_min: 2, days_max: 4, active: true });
  assert.equal((await q(31)).data.delivery_fee, 700);
  await adm.del(`/api/admin/delivery/rates/${(await adm.get('/api/admin/delivery')).data.wilayas.find((w) => w.code === 31).rate.rate_id}`);
  await adm.del(`/api/admin/delivery/rates/${(await adm.get('/api/admin/delivery')).data.wilayas.find((w) => w.code === 25).rate.rate_id}`);
});

test('Order creation: persisted with server-computed totals, stock deducted, history + payment rows', async () => {
  const before = stockOf(shop.variantM.id);
  const r = await pub.post('/api/orders', orderBody(shop.variantM.id, { items: [{ variant_id: shop.variantM.id, qty: 2 }], notes: 'appelez avant' }));
  assert.equal(r.status, 201);
  const o = r.data.order; assert.match(o.number, /^DZ\d{6}-[A-Z2-9]{5}$/);
  assert.equal(o.subtotal, 6000); assert.equal(o.delivery_fee, 500); assert.equal(o.total, 6500); assert.equal(o.status, 'New');
  assert.equal(stockOf(shop.variantM.id), before - 2);
  const row = ctx.db.prepare('SELECT * FROM orders WHERE number=?').get(o.number);
  assert.equal(row.name, 'Karim Test'); assert.equal(row.phone, '0555123456'); assert.equal(row.wilaya_code, 16); assert.equal(row.commune, 'Bab Ezzouar'); assert.equal(row.payment_method, 'cod'); assert.equal(row.notes, 'appelez avant');
  const it = ctx.db.prepare('SELECT * FROM order_items WHERE order_id=?').get(row.id); assert.equal(it.size, 'M'); assert.equal(it.color, 'Noir'); assert.equal(it.qty, 2); assert.equal(it.unit_price, 3000);
  assert.equal(ctx.db.prepare('SELECT COUNT(*) n FROM order_status_history WHERE order_id=?').get(row.id).n, 1);
  assert.equal(ctx.db.prepare('SELECT amount FROM payments WHERE order_id=?').get(row.id).amount, 6500);
  assert.ok(ctx.db.prepare("SELECT 1 FROM inventory_movements WHERE ref=? AND delta=-2 AND reason_code='sale' AND stock_before=stock_after+2").get(o.number));
  assert.ok(ctx.db.prepare("SELECT 1 FROM notifications WHERE type='order'").get(), 'admin notified');
  assert.equal(ctx.db.prepare('SELECT COUNT(*) n FROM customers WHERE phone=?').get('0555123456').n, 1);
});

test('Price tampering is impossible: client-sent prices/totals/fees are ignored', async () => {
  const body = orderBody(shop.variantM.id, { items: [{ variant_id: shop.variantM.id, qty: 1, price: 1, unit_price: 1, line_total: 1 }], price: 1, total: 1, delivery_fee: 0, subtotal: 1 });
  const r = await pub.post('/api/orders', body);
  assert.equal(r.status, 201); assert.equal(r.data.order.total, 3500); assert.equal(r.data.order.delivery_fee, 500);
  const q = await pub.post('/api/quote', { items: [{ variant_id: shop.variantM.id, qty: 1, price: 1 }], wilaya_code: 16, total: 5 }); assert.equal(q.data.total, 3500);
  // client cannot choose arbitrary quantities
  for (const qty of [0, -1, 1.5, '2; DROP', 21]) assert.equal((await pub.post('/api/orders', orderBody(shop.variantM.id, { items: [{ variant_id: shop.variantM.id, qty }] }))).status, 422, String(qty));
  assert.equal((await pub.post('/api/orders', orderBody(shop.variantM.id, { items: [{ variant_id: 999999, qty: 1 }] }))).status, 409);
});

test('Stock management: no overselling, out-of-stock variants blocked, backorder only when enabled', async () => {
  const sp = (await adm.post('/api/admin/products', { name: 'Scarce', price: 1000, variants: [{ size: 'M', color: 'Noir', stock: 3 }, { size: 'L', color: 'Noir', stock: 0 }] })).data;
  const vM = sp.variants.find((v) => v.size === 'M'), vL = sp.variants.find((v) => v.size === 'L');
  const over = await pub.post('/api/orders', orderBody(vM.id, { items: [{ variant_id: vM.id, qty: 4 }] }));
  assert.equal(over.status, 409); assert.equal(over.data.error.code, 'OUT_OF_STOCK'); assert.equal(stockOf(vM.id), 3, 'stock untouched on failure (transaction rolled back)');
  assert.equal((await pub.post('/api/orders', orderBody(vL.id))).status, 409, 'zero-stock variant not purchasable');
  const detail = (await pub.get(`/api/products/${sp.slug}`)).data;
  assert.equal(detail.variants.find((v) => v.size === 'L').available, false); assert.equal(detail.variants.find((v) => v.size === 'M').available, true);
  // multi-line order: second line oversold -> whole order rolls back, first line's stock restored
  const t = await pub.post('/api/orders', orderBody(vM.id, { items: [{ variant_id: vM.id, qty: 1 }, { variant_id: vL.id, qty: 1 }] }));
  assert.equal(t.status, 409); assert.equal(stockOf(vM.id), 3);
  assert.equal(ctx.db.prepare('SELECT COUNT(*) n FROM orders WHERE name=? AND total=1500').get('Karim Test').n, 0);
  // exact remaining stock can be bought, then it is sold out
  assert.equal((await pub.post('/api/orders', orderBody(vM.id, { items: [{ variant_id: vM.id, qty: 3 }] }))).status, 201);
  assert.equal(stockOf(vM.id), 0); assert.equal((await pub.post('/api/orders', orderBody(vM.id))).status, 409);
  // backorder only when explicitly enabled by admin
  const p = (await adm.get(`/api/admin/products/${sp.id}`)).data;
  await adm.put(`/api/admin/products/${p.id}`, { name: p.name, price: p.price, allow_backorder: true, variants: p.variants.map((v) => ({ size: v.size, color: v.color, stock: v.stock })) });
  assert.equal((await pub.post('/api/orders', orderBody(vL.id))).status, 201); assert.equal(stockOf(vL.id), -1);
});

test('Concurrent last-unit purchases cannot oversell', async () => {
  const cat = null;
  const pr = (await adm.post('/api/admin/products', { name: 'Last One', price: 1000, variants: [{ size: 'M', color: 'Noir', stock: 1 }] })).data;
  const vid = pr.variants[0].id;
  const res = await Promise.all([1, 2, 3, 4].map(() => new Client(ctx.base).post('/api/orders', orderBody(vid))));
  assert.equal(res.filter((r) => r.status === 201).length, 1); assert.equal(stockOf(vid), 0);
});

test('Duplicate order prevention: same idempotency key creates ONE order and deducts stock ONCE', async () => {
  const body = orderBody(shop.variantM.id); const s = stockOf(shop.variantM.id);
  const rs = await Promise.all([1, 2, 3].map(() => new Client(ctx.base).post('/api/orders', body)));
  assert.ok(rs.every((r) => [200, 201].includes(r.status)));
  assert.equal(new Set(rs.map((r) => r.data.order.number)).size, 1);
  assert.equal(rs.filter((r) => r.data.duplicate).length, 2);
  assert.equal(stockOf(shop.variantM.id), s - 1);
  assert.equal(ctx.db.prepare('SELECT COUNT(*) n FROM orders WHERE idem_key=?').get(body.idempotency_key).n, 1);
});

test('Checkout validation: required fields, phone format, honeypot, too-fast bot submissions, payment method', async () => {
  const base = () => orderBody(shop.variantM.id);
  const post = (o) => { ctx.app.limiter.reset(); return pub.post('/api/orders', { ...base(), ...o }); };
  assert.equal((await post({ name: 'x' })).status, 422);
  assert.equal((await post({ phone: '12345' })).status, 422);
  assert.equal((await post({ phone: '0455555555x' })).status, 422);
  assert.equal((await post({ address: '' })).status, 422);
  assert.equal((await post({ commune: '' })).status, 422);
  assert.equal((await post({ wilaya_code: 0 })).status, 422);
  assert.equal((await post({ wilaya_code: 31 })).status, 422);
  assert.equal((await post({ payment_method: 'card' })).status, 422);
  assert.equal((await post({ idempotency_key: 'short' })).status, 422);
  assert.equal((await post({ items: [] })).status, 422);
  assert.equal((await post({ website: 'http://spam.example' })).status, 400, 'honeypot');
  assert.equal((await post({ form_started_at: Date.now() })).status, 429, 'submitted instantly');
  assert.equal((await post({ form_started_at: undefined })).status, 429);
  const r = await post({ phone: '+213 555 12 34 56' }); assert.equal(r.status, 201); assert.equal(r.data.order.phone, '0555123456', 'phone normalized');
  const x = await post({ name: '<img src=x onerror=alert(1)>', address: '<script>alert(1)</script> rue 1' }); assert.equal(x.status, 201); // stored as text; UI escapes output
});

test('Order creation is rate limited per IP (anti-spam)', async () => {
  let last; for (let i = 0; i < 12; i++) last = await pub.post('/api/orders', orderBody(shop.variantM.id, { name: 'x' }));
  assert.equal(last.status, 429);
});

test('Order status workflow: allowed transitions, history with user/time, restock on cancel', async () => {
  const o = (await pub.post('/api/orders', orderBody(shop.variantM.id, { items: [{ variant_id: shop.variantM.id, qty: 2 }] }))).data.order;
  const id = ctx.db.prepare('SELECT id FROM orders WHERE number=?').get(o.number).id; const s0 = stockOf(shop.variantM.id);
  const set = (st, note) => adm.post(`/api/admin/orders/${id}/status`, { status: st, note });
  assert.equal((await set('Delivered')).status, 409, 'cannot skip workflow');
  for (const st of ['Confirmed', 'Preparing', 'Shipped']) assert.equal((await set(st)).status, 200, st);
  assert.equal((await set('Cancelled')).status, 409, 'cannot cancel after shipping');
  assert.equal((await set('Failed Delivery', 'client absent')).status, 200);
  assert.equal((await set('Shipped')).status, 200);
  assert.equal((await set('Delivered')).status, 200);
  const d = (await adm.get(`/api/admin/orders/${id}`)).data;
  assert.equal(d.payment_status, 'collected'); assert.deepEqual(d.history.map((h) => h.to_status), ['New', 'Confirmed', 'Preparing', 'Shipped', 'Failed Delivery', 'Shipped', 'Delivered']);
  assert.ok(d.history.slice(1).every((h) => h.actor && h.admin_id && h.created_at));
  assert.equal(d.history[4].note, 'client absent');
  assert.equal((await set('Returned')).status, 200); assert.equal(stockOf(shop.variantM.id), s0 + 2, 'returned goods restocked');
  assert.equal((await set('Confirmed')).status, 409, 'terminal state');
  assert.equal((await set('Nonsense')).status, 422);
  // cancellation restocks exactly once
  const o2 = (await pub.post('/api/orders', orderBody(shop.variantM.id))).data.order; const id2 = ctx.db.prepare('SELECT id FROM orders WHERE number=?').get(o2.number).id; const s1 = stockOf(shop.variantM.id);
  assert.equal((await adm.post(`/api/admin/orders/${id2}/status`, { status: 'Cancelled' })).status, 200); assert.equal(stockOf(shop.variantM.id), s1 + 1);
  assert.equal((await adm.post(`/api/admin/orders/${id2}/status`, { status: 'Cancelled' })).status, 409); assert.equal(stockOf(shop.variantM.id), s1 + 1);
  assert.ok(ctx.db.prepare("SELECT 1 FROM notifications WHERE type='cancel'").get());
  assert.ok(ctx.db.prepare("SELECT 1 FROM audit_logs WHERE action='order.status'").get());
  // role without orders.update cannot change status
  const an = await adminClient(ctx, 'support'); assert.equal((await an.post(`/api/admin/orders/${id}/status`, { status: 'Confirmed' })).status, 403);
});

test('Admin orders list: search by number/phone/name, filter by status/wilaya/date, pagination, details, CSV export', async () => {
  const list = (q) => adm.get('/api/admin/orders?' + q).then((r) => r.data);
  const all = await list(''); assert.ok(all.total > 5);
  assert.ok((await list('q=0555123456')).total > 0); assert.equal((await list('q=0999999999')).total, 0);
  assert.ok((await list('q=' + all.items[0].number)).items.some((x) => x.number === all.items[0].number));
  assert.ok((await list('status=New')).items.every((x) => x.status === 'New'));
  assert.equal((await list('wilaya=31')).total, 0); assert.equal((await list('wilaya=16')).total, all.total);
  const today = require('../server/services/stats').localDay(0); // store day = Algeria (UTC+1) assert.equal((await list(`from=${today}&to=${today}`)).total, all.total); assert.equal((await list('to=2020-01-01')).total, 0);
  const pg = await list('limit=2&page=2'); assert.equal(pg.items.length, 2); assert.ok(pg.pages >= 3);
  assert.equal((await adm.get('/api/admin/orders/999999')).status, 404); assert.equal((await adm.get('/api/admin/orders/abc')).status, 404);
  const csv = await adm.get('/api/admin/orders/export.csv'); assert.equal(csv.status, 200); assert.match(csv.headers.get('content-type'), /text\/csv/); assert.ok(csv.text.includes('Karim Test'));
  assert.ok(!/^=/m.test(csv.text.split('\n').slice(1).join('\n')), 'no formula injection');
});

test('Guest order tracking needs order number AND phone; reveals no other orders', async () => {
  const num = ctx.db.prepare('SELECT number FROM orders ORDER BY id LIMIT 1').get().number;
  assert.equal((await pub.post('/api/orders/track', { number: num, phone: '0699999999' })).status, 404);
  assert.equal((await pub.post('/api/orders/track', { number: num })).status, 404);
  const ok = await pub.post('/api/orders/track', { number: num, phone: '0555123456' }); assert.equal(ok.status, 200); assert.equal(ok.data.order.number, num); assert.ok(ok.data.order.history.length);
});

test('Coupons: server-side validation and usage counting', async () => {
  await adm.post('/api/admin/coupons', { code: 'SALE10', type: 'percent', value: 10, max_uses: 1 });
  const q = (c) => pub.post('/api/quote', { items: [{ variant_id: shop.variantM.id, qty: 1 }], wilaya_code: 16, coupon: c });
  assert.equal((await q('SALE10')).data.discount, 300); assert.equal((await q('NOPE')).status, 422);
  assert.equal((await pub.post('/api/orders', orderBody(shop.variantM.id, { coupon: 'sale10' }))).data.order.total, 3200);
  assert.equal((await q('SALE10')).status, 422, 'max uses reached');
});

test('WhatsApp: number validated & configurable from admin; message contains all order data; number never exposed publicly', async () => {
  const pubCfg = JSON.stringify((await pub.get('/api/config')).data);
  assert.equal((await pub.post('/api/orders', orderBody(shop.variantM.id))).data.whatsapp_url, null, 'no number configured -> no link, no default number');
  for (const bad of ['0555', 'abc', '12345678901', '21355512345', '+33612345678']) assert.equal((await adm.put('/api/admin/settings', { settings: { whatsapp_number: bad } })).status, 422, bad);
  const set = await adm.put('/api/admin/settings', { settings: { whatsapp_number: '+213 555 12 34 56' } }); assert.equal(set.status, 200); assert.equal(set.data.settings.whatsapp_number, '213555123456');
  const r = await pub.post('/api/orders', orderBody(shop.variantM.id, { items: [{ variant_id: shop.variantM.id, qty: 2 }] }));
  const url = new URL(r.data.whatsapp_url); assert.equal(url.origin + url.pathname, 'https://wa.me/213555123456');
  const msg = url.searchParams.get('text');
  for (const part of [r.data.order.number, 'Karim Test', '0555123456', 'Test Hoodie', 'Size: M', 'Color: Noir', 'Qty: 2', 'Subtotal: 6,000 DZD', 'Delivery: 500 DZD', 'Total: 6,500 DZD', 'Wilaya: 16 - Alger', 'Commune: Bab Ezzouar', 'Address: 12 rue des Fleurs']) assert.ok(msg.includes(part), 'missing: ' + part + '\n' + msg);
  assert.ok(!JSON.stringify((await pub.get('/api/config')).data).includes('213555123456'), 'number not leaked in public config');
  assert.ok(!pubCfg.includes('whatsapp_number'));
  assert.ok(orders.buildWhatsappMessage({ number: 'X', name: 'A', phone: '0', items: [], subtotal: 1, discount: 0, delivery_fee: 0, total: 1, wilaya: 'w', commune: 'c', address: 'a' }).includes('Order ID: X'));
});

test('Settings: validation, permissions, maintenance mode', async () => {
  assert.equal((await adm.put('/api/admin/settings', { settings: { store_name: 'Mon Brand', logo_url: 'https://evil/x.png' } })).status, 422);
  assert.equal((await adm.put('/api/admin/settings', { settings: { hacker_key: '1' } })).status, 422);
  assert.equal((await adm.put('/api/admin/settings', { settings: { notify_webhook_url: 'http://insecure' } })).status, 422);
  assert.equal((await adm.put('/api/admin/settings', { settings: { store_name: 'Mon Brand', phone: '0555000000' } })).status, 200);
  assert.equal((await pub.get('/api/config')).data.settings.store_name, 'Mon Brand');
  await adm.put('/api/admin/settings', { settings: { maintenance_mode: '1' } });
  assert.equal((await pub.post('/api/orders', orderBody(shop.variantM.id))).status, 503);
  assert.equal((await pub.get('/')).status, 503);
  await adm.put('/api/admin/settings', { settings: { maintenance_mode: '0' } });
  assert.equal((await pub.get('/')).status, 200);
});

test('Dashboard & analytics are computed from real data', async () => {
  const d = (await adm.get('/api/admin/dashboard')).data; const k = d.kpis;
  const sum = ctx.db.prepare("SELECT COUNT(*) n, SUM(total) s FROM orders WHERE status NOT IN ('Cancelled','Returned','Failed Delivery')").get();
  assert.equal(k.total_sales, sum.s); assert.equal(k.valid_orders, sum.n); assert.equal(k.avg_order_value, Math.round(sum.s / sum.n));
  assert.equal(k.total_orders, ctx.db.prepare('SELECT COUNT(*) n FROM orders').get().n);
  assert.equal(k.cancelled, ctx.db.prepare("SELECT COUNT(*) n FROM orders WHERE status='Cancelled'").get().n);
  assert.ok(d.topProducts[0].qty > 0 && d.topWilayas[0].code === 16 && d.series.length >= 1 && d.recentOrders.length && Array.isArray(d.lowStock));
  assert.ok(d.lowStock.every((x) => x.stock <= x.threshold));
  assert.equal((await adm.get('/api/admin/analytics?from=2020-01-01&to=2020-01-31')).data.kpis.total_orders, 0);
  const cs = (await adm.get('/api/admin/customers')).data.items.find((c) => c.phone === '0555123456'); assert.ok(cs.orders > 5 && cs.spent > 0 && cs.last_order);
});
