'use strict';
const { test, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const { start, Client, makeAdmin, adminClient } = require('./helpers');

let ctx;
before(async () => { ctx = await start(); });
after(async () => { await ctx.close(); });
beforeEach(() => ctx.app.limiter.reset());

test('Admin login works and sets a hardened session cookie', async () => {
  const a = await makeAdmin(ctx.db, 'super_admin', 'owner@test.dz');
  const c = new Client(ctx.base);
  const r = await c.post('/api/admin/login', { email: a.email, password: a.password });
  assert.equal(r.status, 200);
  assert.ok(r.data.csrf);
  const cookie = r.raw.headers.getSetCookie().find((x) => x.startsWith('adm_sid='));
  assert.match(cookie, /HttpOnly/); assert.match(cookie, /SameSite=Strict/); assert.match(cookie, /Path=\/api\/admin/);
  assert.equal(r.data.admin.role, 'super_admin');
  assert.ok(!JSON.stringify(r.data).includes('password'));
});

test('Passwords are hashed (never stored in clear)', async () => {
  const row = ctx.db.prepare("SELECT password_hash FROM admin_users WHERE email='owner@test.dz'").get();
  assert.match(row.password_hash, /^scrypt\$/);
  assert.ok(!row.password_hash.includes('Str0ng'));
});

test('Wrong password and unknown email are rejected with the same generic error', async () => {
  const c = new Client(ctx.base);
  const a = await c.post('/api/admin/login', { email: 'owner@test.dz', password: 'wrong-password-123' });
  const b = await c.post('/api/admin/login', { email: 'nobody@test.dz', password: 'wrong-password-123' });
  assert.equal(a.status, 401); assert.equal(b.status, 401);
  assert.equal(a.data.error.message, b.data.error.message);
});

test('Account locks after 5 failed attempts (even with the right password afterwards)', async () => {
  await makeAdmin(ctx.db, 'manager', 'lock@test.dz', 'Right-Passw0rd-1');
  const c = new Client(ctx.base);
  for (let i = 0; i < 5; i++) assert.equal((await c.post('/api/admin/login', { email: 'lock@test.dz', password: 'bad-password-x1' })).status, 401);
  const r = await c.post('/api/admin/login', { email: 'lock@test.dz', password: 'Right-Passw0rd-1' });
  assert.equal(r.status, 401);
});

test('Login endpoint is rate limited per IP', async () => {
  const c = new Client(ctx.base); let last;
  for (let i = 0; i < 12; i++) last = await c.post('/api/admin/login', { email: 'x@y.dz', password: 'whatever-password1' });
  assert.equal(last.status, 429);
});

test('Unauthorized access: every admin endpoint refuses anonymous callers', async () => {
  const c = new Client(ctx.base);
  const gets = ['/api/admin/me', '/api/admin/dashboard', '/api/admin/orders', '/api/admin/orders/1', '/api/admin/products', '/api/admin/inventory', '/api/admin/customers',
    '/api/admin/delivery', '/api/admin/settings', '/api/admin/users', '/api/admin/logs', '/api/admin/notifications', '/api/admin/coupons', '/api/admin/orders/export.csv'];
  for (const u of gets) assert.equal((await c.get(u)).status, 401, u);
  for (const [u, b] of [['/api/admin/products', {}], ['/api/admin/orders/1/status', { status: 'Confirmed' }], ['/api/admin/delivery/rates', {}], ['/api/admin/users', {}]]) assert.equal((await c.post(u, b)).status, 401, u);
  assert.equal((await c.put('/api/admin/settings', { settings: {} })).status, 401);
});

test('Forged cookie / random token is not accepted', async () => {
  const c = new Client(ctx.base); c.cookies.adm_sid = 'a'.repeat(43);
  assert.equal((await c.get('/api/admin/me')).status, 401);
});

test('CSRF token is mandatory for state-changing admin requests', async () => {
  const c = await adminClient(ctx, 'admin'); const good = c.csrf;
  c.csrf = null;
  assert.equal((await c.post('/api/admin/meta/sizes', { name: 'XXXL' })).status, 403);
  c.csrf = 'wrong-token';
  assert.equal((await c.post('/api/admin/meta/sizes', { name: 'XXXL' })).status, 403);
  c.csrf = good;
  assert.equal((await c.post('/api/admin/meta/sizes', { name: 'XXXL' })).status, 201);
});

test('Cross-origin state-changing requests are blocked', async () => {
  const c = await adminClient(ctx, 'support');
  const r = await c.post('/api/admin/logout', {}, { Origin: 'https://evil.example' });
  assert.equal(r.status, 403);
});

test('RBAC: roles only get their own permissions (server-side)', async () => {
  const support = await adminClient(ctx, 'support');
  assert.equal((await support.get('/api/admin/orders')).status, 200);
  assert.equal((await support.get('/api/admin/customers')).status, 200);
  assert.equal((await support.get('/api/admin/dashboard')).status, 403);
  assert.equal((await support.get('/api/admin/settings')).status, 403);
  assert.equal((await support.post('/api/admin/orders/1/status', { status: 'Confirmed' })).status, 403);
  const orders = await adminClient(ctx, 'order_manager');
  assert.equal((await orders.get('/api/admin/orders')).status, 200);
  assert.equal((await orders.post('/api/admin/products', { name: 'x', price: 1, variants: [] })).status, 403);
  assert.equal((await orders.get('/api/admin/users')).status, 403);
  assert.equal((await orders.get('/api/admin/inventory')).status, 403);
  const inv = await adminClient(ctx, 'inventory_manager');
  assert.equal((await inv.get('/api/admin/orders')).status, 403);
  assert.equal((await inv.get('/api/admin/products')).status, 200);
  assert.equal((await inv.get('/api/admin/inventory')).status, 200);
  assert.equal((await inv.post('/api/admin/products', { name: 'x', price: 1, variants: [] })).status, 403);
  assert.equal((await inv.get('/api/admin/delivery')).status, 403);
  const mgr = await adminClient(ctx, 'manager');
  assert.equal((await mgr.get('/api/admin/delivery')).status, 200); assert.equal((await mgr.get('/api/admin/settings')).status, 403); assert.equal((await mgr.get('/api/admin/logs')).status, 403);
  const admin = await adminClient(ctx, 'admin');
  assert.equal((await admin.get('/api/admin/users')).status, 403, 'only super admin manages users');
  assert.equal((await admin.get('/api/admin/settings')).status, 200);
});

test('Super admin can create users; last super admin cannot be demoted; self lock-out prevented', async () => {
  const s = await adminClient(ctx, 'super_admin');
  const created = await s.post('/api/admin/users', { email: 'new@test.dz', name: 'New Person', role: 'manager', password: 'Another-Passw0rd-9' });
  assert.equal(created.status, 201);
  assert.equal((await s.post('/api/admin/users', { email: 'weak@test.dz', name: 'Weak', role: 'manager', password: 'short' })).status, 422);
  const me = (await s.get('/api/admin/me')).data.admin;
  assert.equal((await s.patch(`/api/admin/users/${me.id}`, { active: false })).status, 409);
  // new user can log in and has manager rights only
  const m = new Client(ctx.base); const l = await m.post('/api/admin/login', { email: 'new@test.dz', password: 'Another-Passw0rd-9' });
  assert.equal(l.status, 200); m.csrf = l.data.csrf;
  assert.equal((await m.get('/api/admin/users')).status, 403);
});

test('Logout invalidates the session server-side', async () => {
  const c = await adminClient(ctx, 'manager'); const token = c.cookies.adm_sid;
  assert.equal((await c.post('/api/admin/logout')).status, 200);
  const d = new Client(ctx.base); d.cookies.adm_sid = token;
  assert.equal((await d.get('/api/admin/me')).status, 401);
});

test('Health check endpoint', async () => {
  const r = await new Client(ctx.base).get('/health'); assert.equal(r.status, 200); assert.equal(r.data.ok, true);
});

test('Security headers (CSP, nosniff, frame, referrer) are set on pages and API', async () => {
  const r = await new Client(ctx.base).get('/health');
  assert.match(r.headers.get('content-security-policy'), /script-src 'self'/);
  assert.match(r.headers.get('content-security-policy'), /frame-ancestors 'none'/);
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
  assert.equal(r.headers.get('x-powered-by'), null);
});

test('Static serving: no path traversal, no dotfiles, no directory listing, 404 page without stack trace', async () => {
  const c = new Client(ctx.base);
  for (const u of ['/../server/config.js', '/%2e%2e/package.json', '/..%2fpackage.json', '/.env', '/css/', '/uploads/../../package.json']) {
    const r = await c.get(u); assert.ok([400, 404].includes(r.status), u + ' -> ' + r.status);
  }
  const r = await c.get('/nope'); assert.equal(r.status, 404); assert.ok(!/at .*\.js/.test(r.text));
});

test('Server errors never leak stack traces or secrets', async () => {
  const r = await new Client(ctx.base).req('POST', '/api/quote', '{"broken', { 'Content-Type': 'application/json' });
  assert.equal(r.status, 400);
  assert.ok(!r.text.includes('node_modules'));
});
