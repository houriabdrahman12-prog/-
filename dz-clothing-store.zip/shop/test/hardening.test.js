'use strict';
const { test, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const { start, Client, adminClient, seedShop, orderBody, PNG } = require('./helpers');
const config = require('../server/config');

let ctx, adm, shop, pub;
before(async () => { ctx = await start(); adm = await adminClient(ctx, 'super_admin'); shop = await seedShop(adm, { stock: 100 }); pub = new Client(ctx.base); });
after(async () => { await ctx.close(); });
beforeEach(() => ctx.app.limiter.reset());

test('Mass assignment: privileged fields sent by clients are ignored (orders, registration, profile, products)', async () => {
  const r = await pub.post('/api/orders', orderBody(shop.variantM.id, { status: 'Delivered', payment_status: 'collected', total: 1, subtotal: 1, account_customer_id: 1, id: 999, stock_restored: 1, delivery_fee: 0 }));
  assert.equal(r.status, 201); const o = ctx.db.prepare('SELECT * FROM orders WHERE number=?').get(r.data.order.number);
  assert.equal(o.status, 'New'); assert.equal(o.payment_status, 'pending'); assert.equal(o.account_customer_id, null); assert.equal(o.stock_restored, 0); assert.notEqual(o.id, 999); assert.ok(o.total > 1);
  const c = new Client(ctx.base); const reg = await c.post('/api/account/register', { name: 'Mass Assign', phone: '0661555001', password: 'Customer-Pass-123', blocked: 1, role: 'super_admin', id: 1, failed_logins: 99 }); assert.equal(reg.status, 201); c.csrf = reg.data.csrf;
  const row = ctx.db.prepare('SELECT * FROM customers WHERE phone=?').get('0661555001'); assert.equal(row.blocked, 0); assert.equal(row.failed_logins, 0);
  assert.equal((await c.get('/api/admin/me')).status, 401);
  await c.patch('/api/account/me', { name: 'Still Me Ok', phone: '0555999888', blocked: 1, password_hash: 'x' }); const after = ctx.db.prepare('SELECT * FROM customers WHERE id=?').get(row.id); assert.equal(after.phone, '0661555001'); assert.equal(after.blocked, 0); assert.notEqual(after.password_hash, 'x');
  const p = (await adm.get(`/api/admin/products/${shop.product.id}`)).data;
  const up = await adm.put(`/api/admin/products/${p.id}`, { name: p.name, price: p.price, id: 12345, archived_at: '2020-01-01', created_at: '1999-01-01', variants: p.variants.map((v) => ({ size: v.size, color: v.color, stock: v.stock })) });
  assert.equal(up.status, 200); assert.equal(up.data.id, p.id); assert.equal(up.data.archived_at, null); assert.notEqual(up.data.created_at, '1999-01-01');
});

test('CORS: no cross-origin access is granted (same-origin only); preflight is not honoured', async () => {
  const r = await pub.get('/api/products', { Origin: 'https://evil.example' }); assert.equal(r.headers.get('access-control-allow-origin'), null); assert.equal(r.headers.get('access-control-allow-credentials'), null);
  const pre = await pub.req('OPTIONS', '/api/orders', undefined, { Origin: 'https://evil.example', 'Access-Control-Request-Method': 'POST' }); assert.equal(pre.status, 405); assert.equal(pre.headers.get('access-control-allow-origin'), null);
  assert.equal(r.headers.get('cross-origin-resource-policy'), 'same-origin');
  for (const path of ['/api/orders', '/api/admin/login', '/api/account/login', '/api/reviews']) assert.equal((await pub.post(path, {}, { Origin: 'https://evil.example' })).status, 403, path);
});

test('Request hygiene: oversized JSON -> 413, wrong content-type -> 415, malformed JSON -> 400, non-object JSON -> 400, bad URL encoding -> 400', async () => {
  const big = '{"x":"' + 'a'.repeat(300 * 1024) + '"}'; assert.equal((await pub.req('POST', '/api/quote', big, { 'Content-Type': 'application/json' })).status, 413);
  assert.equal((await pub.req('POST', '/api/quote', 'x', { 'Content-Type': 'text/plain' })).status, 415); assert.equal((await pub.req('POST', '/api/quote', '{bad', { 'Content-Type': 'application/json' })).status, 400);
  assert.equal((await pub.req('POST', '/api/quote', '"str"', { 'Content-Type': 'application/json' })).status, 400); assert.equal((await pub.get('/api/products/%E0%A4%A')).status, 400);
  assert.equal((await pub.get('/api/does-not-exist')).status, 404); assert.equal((await pub.req('DELETE', '/api/products')).status, 405);
});

test('Source code, database, env and package files are never served', async () => {
  for (const u of ['/server/config.js', '/server/db.js', '/data/store.db', '/package.json', '/.env', '/.env.example', '/scripts/create-admin.js', '/test/auth.test.js', '/Dockerfile', '/README.md']) assert.equal((await pub.get(u)).status, 404, u);
  assert.equal((await pub.get('/uploads/nonexistent.png')).status, 404); assert.equal((await pub.get('/uploads/..%2f..%2fpackage.json')).status, 404);
});

test('Sessions: expiry is enforced, deactivated admins and blocked customers lose access immediately', async () => {
  const c = await adminClient(ctx, 'manager'); assert.equal((await c.get('/api/admin/me')).status, 200);
  ctx.db.prepare("UPDATE sessions SET expires_at='2000-01-01 00:00:00' WHERE token_hash=?").run(require('../server/security').sha256(c.cookies.adm_sid)); assert.equal((await c.get('/api/admin/me')).status, 401, 'expired session rejected');
  const d = await adminClient(ctx, 'support'); const me = (await d.get('/api/admin/me')).data.admin; ctx.db.prepare('UPDATE admin_users SET active=0 WHERE id=?').run(me.id); assert.equal((await d.get('/api/admin/me')).status, 401, 'deactivated admin');
  const cust = new Client(ctx.base); const r = await cust.post('/api/account/register', { name: 'Soon Blocked', phone: '0661555002', password: 'Customer-Pass-123' }); cust.csrf = r.data.csrf; assert.equal((await cust.get('/api/account/orders')).status, 200);
  const cid = ctx.db.prepare("SELECT id FROM customers WHERE phone='0661555002'").get().id; assert.equal((await adm.post(`/api/admin/customers/${cid}/block`, { blocked: true })).status, 200);
  assert.equal((await cust.get('/api/account/orders')).status, 401, 'blocked customer session revoked'); assert.equal((await pub.post('/api/orders', orderBody(shop.variantM.id, { phone: '0661555002' }))).status, 403, 'blocked customer cannot order');
  assert.equal((await new Client(ctx.base).post('/api/account/login', { phone: '0661555002', password: 'Customer-Pass-123' })).status, 401);
  assert.equal((await adm.post(`/api/admin/customers/${cid}/block`, { blocked: false })).status, 200);
});

test('Customer login gives the same error for unknown phone and wrong password; password is never echoed or logged', async () => {
  const a = await pub.post('/api/account/login', { phone: '0661999000', password: 'Whatever-Pass-1' }), b = await pub.post('/api/account/login', { phone: '0661555001', password: 'Wrong-Password-1' });
  assert.equal(a.status, 401); assert.equal(b.status, 401); assert.equal(a.data.error.message, b.data.error.message);
  const ok = await new Client(ctx.base).post('/api/account/login', { phone: '0661555001', password: 'Customer-Pass-123' }); assert.equal(ok.status, 200); assert.ok(!/password|hash|scrypt/i.test(JSON.stringify(ok.data)));
  assert.ok(!(await adm.get('/api/admin/customers')).text.match(/scrypt|password_hash/), 'admin customer list never exposes hashes');
});

test('Production configuration guard refuses unsafe settings', () => {
  const base = { ...config, isProd: true, baseUrl: 'https://shop.example.com', cookieSecure: true, dbPath: '/data/store.db' };
  assert.deepEqual(config.check(base), []);
  assert.match(config.check({ ...base, baseUrl: 'http://shop.example.com' })[0], /BASE_URL must be the public https/);
  assert.match(config.check({ ...base, dbPath: ':memory:' }).join(), /DATABASE_PATH/); assert.match(config.check({ ...base, cookieSecure: false }).join(), /Secure/);
  assert.deepEqual(config.check({ ...base, isProd: false, baseUrl: 'http://localhost:3000', cookieSecure: false }), [], 'development stays easy');
  const { spawnSync } = require('node:child_process'); const r = spawnSync(process.execPath, ['server/index.js'], { cwd: config.root, env: { ...process.env, NODE_ENV: 'production', BASE_URL: 'http://insecure.example.com', DATABASE_PATH: '/tmp/never-created.db' }, encoding: 'utf8', timeout: 8000 });
  assert.notEqual(r.status, 0); assert.match(r.stderr, /Refusing to start/);
});

test('SEO: private pages are noindex, product/category/legal pages are indexable with canonical, html is served with security headers and no inline scripts', async () => {
  const acct = await pub.get('/account'); assert.match(acct.text, /<meta name="robots" content="noindex,follow">/);
  const prod = await pub.get(`/product/${shop.product.slug}`); assert.ok(!/noindex/.test(prod.text)); assert.match(prod.text, /rel="canonical"/); assert.ok(!/<script(?![^>]*(src=|ld\+json))[^>]*>/.test(prod.text), 'no inline JS (CSP)');
  assert.match((await pub.get('/robots.txt')).text, /Disallow: \/admin/); assert.match(prod.headers.get('content-security-policy'), /script-src 'self'/);
  assert.match(prod.text, /class="skip"/); assert.match(prod.text, /<main id="main"/);
});

test('Order data reaches the admin dashboard and survives product edits/archival (end-to-end persistence)', async () => {
  const r = await pub.post('/api/orders', orderBody(shop.variantM.id, { name: 'Persist Check', phone: '0555111000' })); assert.equal(r.status, 201);
  const list = (await adm.get('/api/admin/orders?q=0555111000')).data; assert.equal(list.total, 1); assert.equal(list.items[0].number, r.data.order.number);
  assert.ok((await adm.get('/api/admin/dashboard')).data.recentOrders.some((o) => o.number === r.data.order.number));
  const p = (await adm.get(`/api/admin/products/${shop.product.id}`)).data; await adm.put(`/api/admin/products/${p.id}`, { name: 'Renamed Product', price: 99999, variants: p.variants.map((v) => ({ size: v.size, color: v.color, stock: v.stock })) }); await adm.del(`/api/admin/products/${p.id}`);
  const d = (await adm.get(`/api/admin/orders/${list.items[0].id}`)).data; assert.equal(d.items[0].name, 'Test Hoodie'); assert.equal(d.items[0].unit_price, 3000); assert.equal(d.total, 3000 + 500);
});

test('Phones: only Algerian mobiles (05/06/07) are accepted, international form normalised and exposed to the admin', async () => {
  const pv = (await adm.post('/api/admin/products', { name: 'Phone Test Item', price: 1000, variants: [{ size: 'M', color: 'Noir', stock: 100 }] })).data.variants[0]; const V = pv.id;
  const ok = ['0555123456', '05 55 12 34 56', '+213555123456', '00213555123456', '213555123456', '0555-12-34-56', '0612345678', '0712345678'];
  for (const [i, ph] of ok.entries()) { ctx.app.limiter.reset(); const r = await pub.post('/api/orders', orderBody(V, { phone: ph })); assert.equal(r.status, 201, ph); assert.match(r.data.order.phone, /^0[5-7]\d{8}$/, ph); }
  for (const bad of ['0455123456', '021123456', '0555', '05551234567', 'abcdefghij', '+33612345678', '0855123456', '']) { ctx.app.limiter.reset(); assert.equal((await pub.post('/api/orders', orderBody(V, { phone: bad }))).status, 422, bad); }
  const o = (await adm.get('/api/admin/orders?q=0555123456&limit=1')).data.items[0]; const d = (await adm.get(`/api/admin/orders/${o.id}`)).data; assert.equal(d.phone, '0555123456'); assert.equal(d.phone_intl, '213555123456');
  assert.match((await adm.get('/api/admin/orders/export.csv')).text, /phone_intl/);
});

test('Behind a reverse proxy the client IP is the entry added by OUR proxy (spoofed X-Forwarded-For cannot dodge rate limits)', async () => {
  const px = await start({ trustProxy: true, proxyHops: 1, rate: { ...config.rate, adminLogin: [3, 60000] } });
  try {
    const c = new Client(px.base); const codes = [];
    for (let i = 0; i < 5; i++) codes.push((await c.post('/api/admin/login', { email: 'x@y.dz', password: 'wrong-password-1' }, { 'X-Forwarded-For': `1.1.1.${i}, 203.0.113.9` })).status);
    assert.deepEqual(codes, [401, 401, 401, 429, 429], 'attacker-controlled left entries are ignored; the proxy-added right entry is used');
    assert.equal((await c.post('/api/admin/login', { email: 'x@y.dz', password: 'wrong-password-1' }, { 'X-Forwarded-For': '198.51.100.20' })).status, 401, 'a different real client IP has its own budget');
  } finally { await px.close(); }
  const direct = await start({ trustProxy: false, rate: { ...config.rate, adminLogin: [2, 60000] } });
  try { const c = new Client(direct.base); const st = []; for (let i = 0; i < 3; i++) st.push((await c.post('/api/admin/login', { email: 'x@y.dz', password: 'wrong-password-1' }, { 'X-Forwarded-For': `9.9.9.${i}` })).status); assert.deepEqual(st, [401, 401, 429], 'without TRUST_PROXY the header is ignored entirely'); } finally { await direct.close(); }
});

test('Launch checklist reports GREEN/YELLOW/RED and only reads READY when nothing is blocking', async () => {
  const fresh = await start(); const a = await adminClient(fresh, 'super_admin'); const lv = (r, id) => r.items.find((i) => i.id === id).level;
  try {
    let r = (await a.get('/api/admin/launch-checklist')).data;
    for (const id of ['store_name', 'contact', 'products', 'delivery', 'legal', 'url', 'env']) assert.equal(lv(r, id), 'red', id + ' blocks a fresh install'); assert.equal(r.ready, false); assert.equal(r.status, 'blocked'); assert.ok(r.summary.red >= 7);
    for (const id of ['whatsapp', 'favicon', 'seo', 'backup', 'offsite', 'pages']) assert.equal(lv(r, id), 'yellow', id + ' is a recommendation');
    assert.equal((await (await adminClient(fresh, 'order_manager')).get('/api/admin/launch-checklist')).status, 403);
    const sh = await seedShop(a, { stock: 5 }); assert.equal(lv((await a.get('/api/admin/launch-checklist')).data, 'images'), 'red', 'a sellable product without any image blocks launch');
    const up = (await a.req('POST', '/api/admin/upload', PNG, { 'Content-Type': 'image/png' })).data.url; const pd = (await a.get(`/api/admin/products/${sh.product.id}`)).data;
    assert.equal((await a.put(`/api/admin/products/${pd.id}`, { name: pd.name, price: pd.price, images: [{ url: up }], variants: pd.variants.map((v) => ({ size: v.size, color: v.color, stock: v.stock })) })).status, 200);
    await a.put('/api/admin/settings', { settings: { whatsapp_number: '213555123456', store_name: 'Ma Marque', phone: '0555000000', address: '1 rue X' } });
    for (const slug of ['privacy', 'terms', 'shipping', 'returns']) for (const lang of ['ar', 'fr', 'en']) await a.put(`/api/admin/pages/${slug}/${lang}`, { title: slug, body: 'Real text' });
    r = (await a.get('/api/admin/launch-checklist')).data; for (const id of ['store_name', 'contact', 'products', 'delivery', 'legal', 'prices', 'demo']) assert.equal(lv(r, id), 'green', id);
    assert.deepEqual(r.items.filter((i) => i.level === 'red').map((i) => i.id).sort(), ['env', 'url'], 'only the infrastructure items (https/production env) remain blocking in a test run'); assert.equal(r.ready, false);
    await a.post('/api/admin/products', { name: '[DEMO] leftover', price: 1, variants: [{ size: 'M', color: 'Noir', stock: 1 }] }); assert.equal(lv((await a.get('/api/admin/launch-checklist')).data, 'demo'), 'red', 'leftover demo products block launch');
    await a.post('/api/admin/products', { name: 'Free item', price: 0, variants: [{ size: 'M', color: 'Noir', stock: 1 }] }); assert.equal(lv((await a.get('/api/admin/launch-checklist')).data, 'prices'), 'red', 'zero price blocks launch');
    assert.ok(sh.product.id);
    // a production-like configuration turns the infrastructure items green
    const prodApp = fresh.app; const old = { ...prodApp.config }; Object.assign(prodApp.config, { baseUrl: 'https://shop.example.com', isProd: true, cookieSecure: true, trustProxy: true });
    try { const g = (await a.get('/api/admin/launch-checklist')).data; assert.equal(lv(g, 'url'), 'green'); assert.equal(lv(g, 'env'), 'green'); } finally { Object.assign(prodApp.config, old); }
  } finally { await fresh.close(); }
});

test('Error pages are professional and leak nothing; storefront shell has viewport + safe-area meta; 404 for unknown routes', async () => {
  const r = await pub.get('/this-page-does-not-exist'); assert.equal(r.status, 404); assert.match(r.text, /404/); assert.match(r.text, /class="errpage"/); assert.ok(!/stack|node_modules|\/mnt\//i.test(r.text));
  const home = await pub.get('/'); assert.match(home.text, /viewport-fit=cover/); assert.match(home.text, /<html lang="ar" dir="rtl"/); assert.match(home.text, /<style id="theme">:root\{--bg:#000000/);
  assert.equal((await pub.get('/js/app.js')).headers.get('cache-control'), 'no-cache'); assert.ok((await pub.get('/js/app.js')).headers.get('etag'));
  const et = (await pub.get('/js/app.js')).headers.get('etag'); assert.equal((await pub.get('/js/app.js', { 'If-None-Match': et })).status, 304);
});
