'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const dbm = require('../server/db');
const baseConfig = require('../server/config');
const { runBackup } = require('../scripts/backup');

function tmpEnv() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'shop-bk-'));
  const cfg = { ...baseConfig, dbPath: path.join(dir, 'store.db'), uploadDir: path.join(dir, 'uploads'), backupDir: path.join(dir, 'backups'), backupKeep: 0 };
  const db = dbm.open(cfg.dbPath); dbm.migrate(db); fs.mkdirSync(cfg.uploadDir); fs.writeFileSync(path.join(cfg.uploadDir, 'a.png'), 'img');
  db.prepare("INSERT INTO categories(slug,name) VALUES('x','Persisted')").run();
  return { dir, cfg, db };
}

test('Backup: consistent SQLite snapshot + uploads + manifest/checksum; never deletes old backups unless BACKUP_KEEP is set', async () => {
  const { cfg, db } = tmpEnv();
  const b1 = await runBackup(cfg); await new Promise((r) => setTimeout(r, 15));
  const b2 = await runBackup(cfg); await new Promise((r) => setTimeout(r, 15));
  const b3 = await runBackup(cfg);
  assert.equal(fs.readdirSync(cfg.backupDir).length, 3, 'default: keep everything');
  const man = JSON.parse(fs.readFileSync(path.join(b1.dir, 'manifest.json'), 'utf8')); assert.equal(man.integrity, 'ok'); assert.equal(man.upload_files, 1); assert.match(man.db_sha256, /^[a-f0-9]{64}$/);
  assert.ok(fs.existsSync(path.join(b1.dir, 'uploads', 'a.png')));
  const copy = new DatabaseSync(path.join(b1.dir, 'store.db')); assert.equal(copy.prepare("SELECT name FROM categories WHERE slug='x'").get().name, 'Persisted'); copy.close();
  const keep = await runBackup({ ...cfg, backupKeep: 2 }); assert.equal(keep.removed.length, 2); assert.equal(fs.readdirSync(cfg.backupDir).length, 2, 'retention only when configured');
  db.close();
});

test('Restore: verifies checksum, keeps a safety copy of the current DB, restores data and images', async () => {
  const { cfg, db, dir } = tmpEnv(); const b = await runBackup(cfg);
  db.prepare("INSERT INTO categories(slug,name) VALUES('later','Added after backup')").run(); db.close();
  fs.rmSync(path.join(cfg.uploadDir, 'a.png'));
  const { execFileSync } = require('node:child_process');
  const env = { ...process.env, DATABASE_PATH: cfg.dbPath, UPLOAD_DIR: cfg.uploadDir, BACKUP_DIR: cfg.backupDir };
  execFileSync(process.execPath, [path.join(baseConfig.root, 'scripts/restore.js'), b.dir], { env, stdio: 'pipe' });
  const r = new DatabaseSync(cfg.dbPath); assert.equal(r.prepare("SELECT COUNT(*) n FROM categories WHERE slug='later'").get().n, 0); assert.equal(r.prepare("SELECT COUNT(*) n FROM categories WHERE slug='x'").get().n, 1); r.close();
  assert.ok(fs.existsSync(path.join(cfg.uploadDir, 'a.png'))); assert.ok(fs.readdirSync(dir).some((f) => f.startsWith('store.db.before-restore-')));
  fs.appendFileSync(path.join(b.dir, 'store.db'), 'tamper'); // corrupted backup must be refused
  assert.throws(() => execFileSync(process.execPath, [path.join(baseConfig.root, 'scripts/restore.js'), b.dir], { env, stdio: 'pipe' }), /Command failed/);
});

test('Migrations are forward-only, idempotent and keep foreign keys consistent; seed:demo refuses production', () => {
  const db = dbm.open(':memory:'); dbm.migrate(db); dbm.migrate(db); assert.equal(db.prepare('PRAGMA user_version').get().user_version, 3);
  assert.deepEqual(db.prepare('PRAGMA foreign_key_check').all(), []); assert.equal(db.prepare('PRAGMA foreign_keys').get().foreign_keys, 1);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM wilayas').get().n, 58); assert.equal(db.prepare('SELECT COUNT(*) n FROM roles').get().n >= 7, true); assert.equal(db.prepare('SELECT COUNT(*) n FROM cms_pages').get().n, 24);
  assert.equal(db.prepare("SELECT COUNT(*) n FROM admin_users").get().n, 0, 'no default admin'); assert.equal(db.prepare('SELECT COUNT(*) n FROM delivery_rates').get().n, 0, 'no default delivery prices'); assert.equal(db.prepare("SELECT value FROM settings WHERE key='whatsapp_number'").get().value, '', 'no default WhatsApp number');
  const { spawnSync } = require('node:child_process');
  const r = spawnSync(process.execPath, [path.join(baseConfig.root, 'scripts/seed-demo.js')], { env: { ...process.env, NODE_ENV: 'production', DATABASE_PATH: ':memory:' }, encoding: 'utf8' });
  assert.notEqual(r.status, 0); assert.match(r.stderr, /Refusing/);
});
