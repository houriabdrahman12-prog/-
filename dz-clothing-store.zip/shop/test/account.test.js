'use strict';
const { test, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const { start, Client, adminClient, seedShop, orderBody } = require('./helpers');

let ctx, adm, shop;
before(async () => { ctx = await start(); adm = await adminClient(ctx, 'super_admin'); shop = await seedShop(adm, { stock: 50 }); });
after(async () => { await ctx.close(); });
beforeEach(() => ctx.app.limiter.reset());

async function register(phone, name = 'Client Test') {
  const c = new Client(ctx.base);
  const r = await c.post('/api/account/register', { name, phone, password: 'Customer-Pass-123' });
  assert.equal(r.status, 201, r.text); c.csrf = r.data.csrf; return c;
}

test('Guest checkout works with no account; optional account for tracking orders', async () => {
  const guest = new Client(ctx.base);
  assert.equal((await guest.post('/api/orders', orderBody(shop.variantM.id))).status, 201);
  const a = await register('0666111111');
  const r = await a.post('/api/orders', orderBody(shop.variantM.id, { phone: '0666111111' })); assert.equal(r.status, 201);
  const mine = await a.get('/api/account/orders'); assert.equal(mine.data.orders.length, 1); assert.equal(mine.data.orders[0].number, r.data.order.number);
});

test('Account security: password policy, hashing, duplicate phone, lockout, httpOnly cookie, logout', async () => {
  const c = new Client(ctx.base);
  assert.equal((await c.post('/api/account/register', { name: 'Weak User', phone: '0666222222', password: 'short' })).status, 422);
  assert.equal((await c.post('/api/account/register', { name: 'Bad Phone', phone: '123', password: 'Customer-Pass-123' })).status, 422);
  const a = await register('0666222222');
  const row = ctx.db.prepare('SELECT password_hash FROM customers WHERE phone=?').get('0666222222'); assert.match(row.password_hash, /^scrypt\$/);
  assert.equal((await new Client(ctx.base).post('/api/account/register', { name: 'Again', phone: '0666222222', password: 'Customer-Pass-123' })).status, 409);
  assert.match(a.cookies.cus_sid.length > 20 ? 'ok' : 'short', /ok/);
  const l = new Client(ctx.base); for (let i = 0; i < 5; i++) await l.post('/api/account/login', { phone: '0666222222', password: 'wrong-wrong-1' });
  assert.equal((await l.post('/api/account/login', { phone: '0666222222', password: 'Customer-Pass-123' })).status, 401, 'locked');
  assert.equal((await a.post('/api/account/logout')).status, 200); assert.equal((await a.get('/api/account/orders')).status, 401);
});

test('IDOR/BOLA: customers only see their own orders; guests cannot read account data; customers cannot use admin API', async () => {
  const a = await register('0666333333', 'Alice Test'), b = await register('0666444444', 'Bob Test');
  const oa = (await a.post('/api/orders', orderBody(shop.variantM.id, { phone: '0666333333', name: 'Alice Test' }))).data.order;
  assert.equal((await b.get('/api/account/orders')).data.orders.length, 0);
  assert.equal((await b.get(`/api/account/orders/${oa.number}/reorder`)).status, 404);
  assert.equal((await a.get(`/api/account/orders/${oa.number}/reorder`)).status, 200);
  assert.equal((await new Client(ctx.base).get('/api/account/orders')).status, 401);
  assert.equal((await b.get('/api/admin/orders')).status, 401); assert.equal((await b.get('/api/admin/me')).status, 401);
  // account cookie cannot be replayed as admin cookie
  const x = new Client(ctx.base); x.cookies.adm_sid = a.cookies.cus_sid; assert.equal((await x.get('/api/admin/me')).status, 401);
  // addresses & wishlist are scoped too
  const addr = await a.post('/api/account/addresses', { wilaya_code: 16, commune: 'Hydra', address: '5 rue Didouche' }); assert.equal(addr.status, 201);
  assert.equal((await b.del(`/api/account/addresses/${addr.data.id}`)).status, 404); assert.equal((await a.del(`/api/account/addresses/${addr.data.id}`)).status, 200);
  assert.equal((await a.post(`/api/account/wishlist/${shop.product.id}`)).status, 200); assert.equal((await a.get('/api/account/wishlist')).data.ids.length, 1); assert.equal((await b.get('/api/account/wishlist')).data.ids.length, 0);
  // CSRF on customer writes
  const noCsrf = new Client(ctx.base); noCsrf.cookies.cus_sid = a.cookies.cus_sid; assert.equal((await noCsrf.post(`/api/account/wishlist/${shop.product.id}`)).status, 403);
});

test('Registering with a phone that has guest orders does NOT expose those old orders', async () => {
  await new Client(ctx.base).post('/api/orders', orderBody(shop.variantM.id, { phone: '0666555555', name: 'Victim User' }));
  const attacker = await register('0666555555', 'Attacker');
  assert.equal((await attacker.get('/api/account/orders')).data.orders.length, 0);
});

test('Reviews: anti-bot, moderation before publication', async () => {
  const pub = new Client(ctx.base);
  const body = { product_id: shop.product.id, name: 'Sami', rating: 5, body: 'Super qualité', form_started_at: Date.now() - 5000 };
  assert.equal((await pub.post('/api/reviews', { ...body, website: 'spam' })).status, 400);
  assert.equal((await pub.post('/api/reviews', { ...body, form_started_at: Date.now() })).status, 429);
  assert.equal((await pub.post('/api/reviews', { ...body, rating: 9 })).status, 422);
  assert.equal((await pub.post('/api/reviews', body)).status, 201);
  assert.equal((await pub.get(`/api/products/${shop.product.slug}`)).data.reviews.length, 0, 'pending reviews hidden');
  const id = (await adm.get('/api/admin/reviews?status=pending')).data.items[0].id; assert.equal((await adm.post(`/api/admin/reviews/${id}/approve`)).status, 200);
  const d = (await pub.get(`/api/products/${shop.product.slug}`)).data; assert.equal(d.reviews.length, 1); assert.equal(d.rating.avg, 5);
});

test('SEO: sitemap, robots, product page meta + structured data, canonical, 404 for unknown product', async () => {
  const pub = new Client(ctx.base);
  const robots = (await pub.get('/robots.txt')).text; assert.match(robots, /Disallow: \/admin/); assert.match(robots, /Sitemap: .*\/sitemap.xml/);
  const sm = (await pub.get('/sitemap.xml')).text; assert.match(sm, /<urlset/); assert.ok(sm.includes(`/product/${shop.product.slug}`));
  const page = await pub.get(`/product/${shop.product.slug}`); assert.equal(page.status, 200);
  assert.match(page.text, /<link rel="canonical" href="[^"]+\/product\/test-hoodie">/); assert.match(page.text, /property="og:title"/); assert.match(page.text, /twitter:card/);
  const ld = [...page.text.matchAll(/<script type="application\/ld\+json">(.*?)<\/script>/g)].map((m) => JSON.parse(m[1]));
  const prod = ld.find((x) => x['@type'] === 'Product'); assert.equal(prod.offers.priceCurrency, 'DZD'); assert.equal(prod.offers.availability, 'https://schema.org/InStock');
  assert.ok(ld.find((x) => x['@type'] === 'BreadcrumbList'));
  assert.equal((await pub.get('/product/does-not-exist')).status, 404);
  assert.ok((await pub.get('/')).text.includes('Organization'));
  // XSS in product name cannot break out of meta/JSON-LD
  await adm.post('/api/admin/products', { name: '"><script>alert(1)</script>', price: 10, variants: [{ size: 'M', color: 'Noir', stock: 1 }], slug: 'xss-test' });
  const x = await pub.get('/product/xss-test'); assert.ok(!x.text.includes('<script>alert(1)'), 'escaped'); 
  assert.equal((await pub.get('/admin')).status, 200);
});
