'use strict';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const baseConfig = require('../server/config');
const { build } = require('../server/index');
const sec = require('../server/security');

async function start(overrides = {}) {
  const uploadDir = fs.mkdtempSync(path.join(os.tmpdir(), 'shop-up-'));
  const cfg = { ...baseConfig, dbPath: ':memory:', uploadDir, cookieSecure: false, ...overrides };
  const app = build({ cfg, quiet: true });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${app.server.address().port}`;
  return { app, base, db: app.db, close: () => new Promise((r) => { app.server.close(r); app.server.closeAllConnections?.(); }) };
}

class Client {
  constructor(base) { this.base = base; this.cookies = {}; this.csrf = null; }
  async req(method, url, body, headers = {}) {
    const h = { ...headers };
    if (body !== undefined && !(body instanceof Buffer) && !h['Content-Type']) h['Content-Type'] = 'application/json';
    if (this.csrf && method !== 'GET') h['X-CSRF-Token'] = this.csrf;
    const ck = Object.entries(this.cookies).map(([k, v]) => `${k}=${v}`).join('; ');
    if (ck) h.Cookie = ck;
    const res = await fetch(this.base + url, { method, headers: h, body: body === undefined ? undefined : body instanceof Buffer ? body : JSON.stringify(body), redirect: 'manual' });
    for (const c of res.headers.getSetCookie?.() || []) {
      const [pair] = c.split(';'); const i = pair.indexOf('=');
      const name = pair.slice(0, i), val = pair.slice(i + 1);
      if (/Max-Age=0/i.test(c) || val === '') delete this.cookies[name]; else this.cookies[name] = val;
    }
    const text = await res.text();
    let data = null; try { data = JSON.parse(text); } catch { /* not json */ }
    return { status: res.status, data, text, headers: res.headers, raw: res };
  }
  get(u, h) { return this.req('GET', u, undefined, h); }
  post(u, b = {}, h) { return this.req('POST', u, b, h); }
  put(u, b = {}) { return this.req('PUT', u, b); }
  patch(u, b = {}) { return this.req('PATCH', u, b); }
  del(u) { return this.req('DELETE', u); }
}

async function makeAdmin(db, role = 'super_admin', email = `${role}@test.dz`, password = 'Str0ng-Passw0rd!') {
  const r = db.prepare('SELECT id FROM roles WHERE code=?').get(role);
  db.prepare('INSERT INTO admin_users(email,name,password_hash,role_id) VALUES(?,?,?,?)').run(email, role, await sec.hashPassword(password), r.id);
  return { email, password };
}
let seq = 0;
async function adminClient(ctx, role = 'super_admin') {
  const c = new Client(ctx.base);
  const a = await makeAdmin(ctx.db, role, `${role}-${++seq}@test.dz`);
  const r = await c.post('/api/admin/login', { email: a.email, password: a.password });
  if (r.status !== 200) throw new Error('admin login failed ' + r.status + r.text);
  c.csrf = r.data.csrf;
  return c;
}

// minimal valid 1x1 PNG
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', 'base64');

/** creates a delivery rate + a product with variants through the real admin API */
async function seedShop(adm, { stock = 5, price = 3000, fee = 500 } = {}) {
  await adm.post('/api/admin/delivery/rates', { wilaya_code: 16, price: fee, days_min: 1, days_max: 2, active: true });
  const cat = (await adm.post('/api/admin/meta/categories', { name: 'Hoodies' })).data.id;
  const r = await adm.post('/api/admin/products', {
    name: 'Test Hoodie', price, category_id: cat, description: 'desc',
    variants: [{ size: 'M', color: 'Noir', stock }, { size: 'L', color: 'Noir', stock: 0 }],
  });
  return { product: r.data, variantM: r.data.variants.find((v) => v.size === 'M'), variantL: r.data.variants.find((v) => v.size === 'L') };
}
const orderBody = (variantId, extra = {}) => ({
  name: 'Karim Test', phone: '0555123456', wilaya_code: 16, commune: 'Bab Ezzouar', address: '12 rue des Fleurs', payment_method: 'cod',
  idempotency_key: 'key-' + Math.random().toString(36).slice(2) + Date.now().toString(36), form_started_at: Date.now() - 10_000,
  items: [{ variant_id: variantId, qty: 1 }], ...extra,
});

module.exports = { start, Client, makeAdmin, adminClient, seedShop, orderBody, PNG };
