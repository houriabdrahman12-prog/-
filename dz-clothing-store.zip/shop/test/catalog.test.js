'use strict';
const { test, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { start, Client, adminClient, seedShop, orderBody, PNG } = require('./helpers');

let ctx, adm;
before(async () => { ctx = await start(); adm = await adminClient(ctx, 'super_admin'); });
after(async () => { await ctx.close(); });
beforeEach(() => ctx.app.limiter.reset());

test('Product CRUD: create, read, update (price/stock/variants), archive', async () => {
  const cat = (await adm.post('/api/admin/meta/categories', { name: 'T-shirts' })).data.id;
  const c = await adm.post('/api/admin/products', {
    name: 'Tee Orbit', price: 2800, compare_price: 3500, category_id: cat, sku: 'TEE-1', tags: 'tee,orbit', featured: true, new_arrival: true,
    seo_title: 'Tee Orbit', seo_description: 'desc', variants: [{ size: 'S', color: 'Noir', stock: 4, color_hex: '#000000' }, { size: 'M', color: 'Blanc', stock: 6 }],
  });
  assert.equal(c.status, 201);
  const p = c.data; assert.equal(p.slug, 'tee-orbit'); assert.equal(p.variants.length, 2); assert.equal(p.featured, 1);
  const read = await adm.get(`/api/admin/products/${p.id}`); assert.equal(read.data.name, 'Tee Orbit');

  const v = p.variants.map((x) => ({ size: x.size, color: x.color, stock: x.size === 'S' ? 10 : x.stock }));
  v.push({ size: 'XL', color: 'Noir', stock: 3 });
  const u = await adm.put(`/api/admin/products/${p.id}`, { name: 'Tee Orbit', price: 2600, compare_price: 3500, category_id: cat, variants: v });
  assert.equal(u.status, 200); assert.equal(u.data.price, 2600); assert.equal(u.data.variants.length, 3);
  assert.equal(u.data.variants.find((x) => x.size === 'S').stock, 10);

  // stock history recorded for the admin edit
  const sv = u.data.variants.find((x) => x.size === 'S');
  const h = await adm.get(`/api/admin/inventory/${sv.id}/history`);
  assert.ok(h.data.items.some((m) => m.reason_code === 'correction' && m.delta === 6 && m.stock_before === 4 && m.stock_after === 10));

  // price change is audited with who did it
  const logs = (await adm.get('/api/admin/logs?action=product.update')).data.items;
  assert.ok(logs.length && JSON.parse(logs[0].detail).price_from === 2800 && logs[0].actor_email);

  // removing a variant from the form deactivates (never deletes) it
  const u2 = await adm.put(`/api/admin/products/${p.id}`, { name: 'Tee Orbit', price: 2600, variants: v.filter((x) => x.size !== 'XL') });
  assert.equal(u2.data.variants.find((x) => x.size === 'XL').active, 0);

  const del = await adm.del(`/api/admin/products/${p.id}`); assert.equal(del.status, 200);
  const pub = await new Client(ctx.base).get('/api/products/tee-orbit'); assert.equal(pub.status, 404);
  assert.equal((await adm.get('/api/admin/products?archived=1')).data.items.length, 1);
  assert.equal((await adm.post(`/api/admin/products/${p.id}/restore`)).status, 200);
});

test('Product validation rejects bad input with field errors', async () => {
  const bad = await adm.post('/api/admin/products', { name: 'x', price: -5, variants: 'nope' });
  assert.equal(bad.status, 422); assert.ok(bad.data.error.details.name && bad.data.error.details.price);
  const dup = await adm.post('/api/admin/products', { name: 'Dup', price: 100, variants: [{ size: 'M', color: 'Noir', stock: 1 }, { size: 'm', color: 'noir', stock: 1 }] });
  assert.equal(dup.status, 422);
  const cmp = await adm.post('/api/admin/products', { name: 'Cmp', price: 500, compare_price: 100, variants: [] });
  assert.equal(cmp.status, 422);
  const xss = await adm.post('/api/admin/products', { name: 'Img', price: 5, images: [{ url: 'https://evil.com/x.png' }], variants: [] });
  assert.equal(xss.status, 422);
});

test('Products with historical orders are archived, never hard-deleted: order data survives', async () => {
  const { product, variantM } = await seedShop(adm);
  const o = await new Client(ctx.base).post('/api/orders', orderBody(variantM.id));
  assert.equal(o.status, 201);
  assert.equal((await adm.del(`/api/admin/products/${product.id}`)).status, 200);
  const row = ctx.db.prepare('SELECT * FROM products WHERE id=?').get(product.id);
  assert.ok(row && row.archived_at);
  const detail = (await adm.get(`/api/admin/orders/${ctx.db.prepare('SELECT id FROM orders').get().id}`)).data;
  assert.equal(detail.items[0].name, 'Test Hoodie'); assert.equal(detail.items[0].unit_price, 3000);
  // archived product can no longer be ordered
  const again = await new Client(ctx.base).post('/api/orders', orderBody(variantM.id));
  assert.equal(again.status, 409);
});

test('Public catalog: search, filters, sorting, pagination, availability', async () => {
  const { product, variantM } = await seedShop(adm).catch(() => ({}));
  const pub = new Client(ctx.base);
  await adm.post('/api/admin/products', { name: 'Pantalon Cargo', price: 6000, variants: [{ size: 'L', color: 'Vert', stock: 2 }] });
  await adm.post('/api/admin/products', { name: 'Casquette Out', price: 1500, variants: [{ size: 'M', color: 'Noir', stock: 0 }] });
  assert.equal((await pub.get('/api/products?q=cargo')).data.total, 1);
  assert.equal((await pub.get('/api/products?q=%25')).data.total, 0, 'LIKE wildcards are escaped');
  assert.equal((await pub.get('/api/products?color=Vert')).data.items[0].name, 'Pantalon Cargo');
  assert.equal((await pub.get('/api/products?size=L&color=Vert')).data.total, 1);
  const out = await pub.get('/api/products?avail=out'); assert.ok(out.data.items.some((x) => x.name === 'Casquette Out'));
  const asc = (await pub.get('/api/products?sort=price_asc')).data.items.map((x) => x.price);
  assert.deepEqual(asc, [...asc].sort((a, b) => a - b));
  assert.equal((await pub.get('/api/products?min=5000')).data.items.every((x) => x.price >= 5000), true);
  const pg = (await pub.get('/api/products?limit=1&page=2')).data; assert.equal(pg.items.length, 1); assert.ok(pg.pages >= 2);
  const inj = await pub.get("/api/products?q=' OR 1=1 --&category=x'; DROP TABLE products;--");
  assert.equal(inj.status, 200); assert.ok(ctx.db.prepare('SELECT COUNT(*) n FROM products').get().n > 0);
});

test('Image upload: validates type (magic bytes), size and requires permission', async () => {
  const ok = await adm.req('POST', '/api/admin/upload', PNG, { 'Content-Type': 'image/png' });
  assert.equal(ok.status, 201); assert.match(ok.data.url, /^\/uploads\/[a-f0-9-]{36}\.(png|webp)$/);
  assert.ok(fs.existsSync(path.join(ctx.app.config.uploadDir, path.basename(ok.data.url))));
  const served = await new Client(ctx.base).get(ok.data.url); assert.equal(served.status, 200); assert.match(served.headers.get('content-type'), /^image\/(png|webp)$/);
  const html = await adm.req('POST', '/api/admin/upload', Buffer.from('<script>alert(1)</script>'.padEnd(40, ' ')), { 'Content-Type': 'image/png' });
  assert.equal(html.status, 415);
  const mismatch = await adm.req('POST', '/api/admin/upload', PNG, { 'Content-Type': 'image/jpeg' }); assert.equal(mismatch.status, 415);
  const big = await adm.req('POST', '/api/admin/upload', Buffer.concat([PNG, Buffer.alloc(4 * 1024 * 1024)]), { 'Content-Type': 'image/png' });
  assert.equal(big.status, 413);
  const nobody = await new Client(ctx.base).req('POST', '/api/admin/upload', PNG, { 'Content-Type': 'image/png' }); assert.equal(nobody.status, 401);
  const pm = await adminClient(ctx, 'order_manager'); assert.equal((await pm.req('POST', '/api/admin/upload', PNG, { 'Content-Type': 'image/png' })).status, 403);
  // image can be attached to a product
  const p = await adm.post('/api/admin/products', { name: 'With Image', price: 100, images: [{ url: ok.data.url, alt: 'x' }], variants: [] });
  assert.equal(p.data.images[0].url, ok.data.url);
});

test('Bulk actions and meta management', async () => {
  const a = (await adm.post('/api/admin/products', { name: 'Bulk A', price: 10, variants: [] })).data.id;
  const b = (await adm.post('/api/admin/products', { name: 'Bulk B', price: 10, variants: [] })).data.id;
  const r = await adm.post('/api/admin/products/bulk', { ids: [a, b], action: 'deactivate' });
  assert.equal(r.data.updated, 2); assert.equal(ctx.db.prepare('SELECT active FROM products WHERE id=?').get(a).active, 0);
  assert.equal((await adm.post('/api/admin/products/bulk', { ids: [], action: 'archive' })).status, 422);
  assert.equal((await adm.post('/api/admin/meta/sizes', { name: '3XL' })).status, 201);
  assert.equal((await adm.post('/api/admin/meta/sizes', { name: '3xl' })).status, 409);
  assert.equal((await adm.post('/api/admin/meta/colors', { name: 'Bleu', hex: '#0000ff' })).status, 201);
  assert.equal((await adm.post('/api/admin/meta/colors', { name: 'Bad', hex: 'blue' })).status, 422);
});
